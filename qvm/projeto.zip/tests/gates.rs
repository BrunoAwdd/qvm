mod gates {
    mod cnot_test;
    mod hadamard_test;
    mod pauli_x_test;
    mod pauli_y_test;
    mod pauli_z_test;
}