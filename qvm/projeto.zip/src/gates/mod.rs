pub mod hadamard;
pub mod pauli_x;
pub mod pauli_y;
pub mod pauli_z;
pub mod cnot;
pub mod quantum_gate_abstract;
